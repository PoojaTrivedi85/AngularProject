export class QuizConfig {
    allowBack: boolean;
    allowReview: boolean;
    autoMove: boolean;  
    pageSize: number;
    theme: string;

    constructor(data: any) {
        data = data || {};
        this.allowBack = data.allowBack;
        this.allowReview = data.allowReview;
        this.autoMove = data.autoMove;
        this.pageSize = data.pageSize;
    }
}
